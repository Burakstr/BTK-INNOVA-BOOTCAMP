import UIKit

var sayilar = [Int]()

var meyveler = [String]()

meyveler.append("Elma")//0.
meyveler.append("Kiraz")//1.
meyveler.append("Muz")//2.

print(meyveler)

meyveler[1] = "Yeni Kiraz"
print(meyveler)

meyveler.insert("Portakal", at: 1)
print(meyveler)

print("Boyut : \(meyveler.count)")
print("Arama : \(meyveler.contains("Muz"))")
meyveler.reverse()
print(meyveler)

meyveler.sort()
print(meyveler)

//Nesne Tabanlı
class Yemekler {
    var id:Int?
    var ad:String?
    var fiyat:Int?
    
    init(id: Int, ad: String, fiyat: Int) {
        self.id = id
        self.ad = ad
        self.fiyat = fiyat
    }
}

let y1 = Yemekler(id: 1, ad: "Makarna", fiyat: 200)
let y2 = Yemekler(id: 2, ad: "Pilav", fiyat: 60)
let y3 = Yemekler(id: 3, ad: "Kavurma", fiyat: 300)

var yemeklerListesi = [Yemekler]()
yemeklerListesi.append(y1)
yemeklerListesi.append(y2)
yemeklerListesi.append(y3)

for yemek in yemeklerListesi {
    print("---------------------")
    print("Id    : \(yemek.id!)")
    print("Ad    : \(yemek.ad!)")
    print("Fiyat : \(yemek.fiyat!) ₺")
}

//Sıralama - Sort
print("---------------------")
print("Fiyata Göre Azalan")
let siralama1 = yemeklerListesi.sorted(by:{$0.fiyat! > $1.fiyat! })

for yemek in siralama1 {
    print("---------------------")
    print("Id    : \(yemek.id!)")
    print("Ad    : \(yemek.ad!)")
    print("Fiyat : \(yemek.fiyat!) ₺")
}
print("---------------------")
print("Fiyata Göre Artan")
let siralama2 = yemeklerListesi.sorted(by:{$0.fiyat! < $1.fiyat! })

for yemek in siralama2 {
    print("---------------------")
    print("Id    : \(yemek.id!)")
    print("Ad    : \(yemek.ad!)")
    print("Fiyat : \(yemek.fiyat!) ₺")
}

//Filitreleme
print("---------------------")
print("Filtreleme 1")
let filtreleme1 = yemeklerListesi.filter({$0.fiyat! > 100 && $0.fiyat! < 250 })

for yemek in filtreleme1 {
    print("---------------------")
    print("Id    : \(yemek.id!)")
    print("Ad    : \(yemek.ad!)")
    print("Fiyat : \(yemek.fiyat!) ₺")
}

print("---------------------")
print("Filtreleme 2")
let filtreleme2 = yemeklerListesi.filter({$0.ad!.contains("avu")})

for yemek in filtreleme2 {
    print("---------------------")
    print("Id    : \(yemek.id!)")
    print("Ad    : \(yemek.ad!)")
    print("Fiyat : \(yemek.fiyat!) ₺")
}

//Set - HashSet
var sayilar2 = Set<Int>()

var meyveler2 = Set<String>()

meyveler2.insert("Kiraz")
meyveler2.insert("Elma")
meyveler2.insert("Muz")

print(meyveler2)

meyveler2.insert("Amasya Elması")
print(meyveler2)

print("Boyut : \(meyveler2.count)")

for (indeks,meyve) in meyveler2.enumerated() {
    print("\(indeks). ->Sonuç : \(meyve)")
}

//Dictionary - Map - HashMap (JSON veri modelinin temeli)

var d1 = [Int:String]()

var d2 = ["ad":"Ahmet","soyad":"Aksoy"]

var iller = [Int:String]()

iller[16] = "BURSA"
iller[34] = "İSTANBUL"
iller[6] = "ANKARA"
print(iller)

iller[16] = "YENİ BURSA"
print(iller)

for (anahtar,deger) in iller {
    print("\(anahtar) -> \(deger)")
}

//Guard (if tersi) false durumunda çalışır
func selamla1(ad:String){
    if ad == "Burak" {
        print("Merhaba Burak")
    }else{
        print("Tanınmayan Kişi")
    }
}

func selamla2(ad:String){
    guard ad == "Burak" else {
        print("Tanınmayan Kişi")
        return
    }
    print("Merhaba Burak")
}
selamla1(ad: "Burak")
selamla2(ad: "Ahmet")


func buyukHarf1(yazi:String?){
    if let temp = yazi {
        print("Sonuç : \(temp.uppercased())")
    }else {
        print("İçerik boş")
        return
    }
}

func buyukHarf2(yazi:String?){
    guard let temp = yazi else {
        print("İçerik boş")
        return
    }
    print("Sonuç : \(temp.uppercased())")
}

buyukHarf1(yazi: "Merhaba")
buyukHarf2(yazi: nil)

//Try catch


//1.Compile Error :
let x = 10
//x = 30
//2.Runtime Error (Exception) :


enum Hata : Error {
    case sifiraBolunme
}

func bolme(s1:Int,s2:Int) throws -> Int{
    if s2 == 0 {
        throw Hata.sifiraBolunme
    }
    return s1 / s2
}

let s1 = 10
let s2 = 0

do{
    let sonuc = try bolme (s1:10 , s2: 0)
    print("Sonuç : \(sonuc)")
}catch{
    print("Sıfıra bölünme hatası")
}

let sonuc1 = try? bolme (s1:10 , s2: 5)
print("Sonuç : \(sonuc1!)")


