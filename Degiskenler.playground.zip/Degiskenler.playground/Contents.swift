import UIKit

var ogrenciAd = "Ahmet"
var ogrenciYas = 23
var ogrenciBoy = 1.78
var ogrenciBasharf = "A"
var ogrenciDevamDurumu = true

print("Ögrenci Adı          : \(ogrenciAd)")
print("Ögrenci Yaş          : \(ogrenciYas)")
print("Ögrenci Boy          : \(ogrenciBoy)")
print("Ögrenci Basharf      : \(ogrenciBasharf)")
print("Ögrenci Devam Durumu : \(ogrenciDevamDurumu)")

//Sabitler - Constant
var sayi = 100
print(sayi)
sayi = 300
print(sayi)

let numara = 50
print(numara)

// Tür Dönüşümü - Type Casting
// Sayısaldan Sayısala
var i = 42
var d = 37.93

var sonuc1 = Double(i)
var sonuc2 = Int(d)
print(sonuc1)
print(sonuc2)

// Sayısaldan Metine
var sonuc3 = String(d)
print(sonuc3)

// Metinden Sayısala
var yazi = "57"

if let sonuc4 = Int(yazi) {
    print(sonuc4)
}else{
    print("Dönüşümde Hata Oluştu")
}

//Tuples
var kisi = ("Ahmet","Aksoy",30)
var ad = kisi.0
print(ad)
