import UIKit
// Optional
var mesaj:String?

mesaj = "Hello"

if mesaj != nil {
    print(mesaj!)//Optional unwrap
}else{
    print("Mesaj Boş")
}

if let temp = mesaj {// Optional Binding
    print(temp)
}else{
    print("Mesaj Boş")
}

if var temp = mesaj {// Optional Binding
    print(temp)
    temp = "How are you"
    print(temp)
}else{
    print("Mesaj Boş")
}

