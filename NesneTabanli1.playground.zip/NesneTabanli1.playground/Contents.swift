import UIKit

class Urunler {
    var id:Int?
    var ad:String?
    var fiyat:Int?
    
    init(){//constructor
        print("Nesne oluşturuldu")
    }
    
    init(id:Int,ad:String,fiyat:Int){
        self.id = id
        self.ad = ad
        self.fiyat = fiyat // Shadowing
        
    }
    
    func bilgiAl(){
        print("--------------------------")
        print("Id    : \(id!)")
        print("Ad    : \(ad!)")
        print("Fiyat : \(fiyat!) ₺")
    }
    // self : bulundugu sınıfı temsil eder.
    //super : kalıtım varsa üst sınıfı temsil eder
    
    func guncelle(miktar:Int) { // Side effect fonksiyon kullanıp icerigi degistirmeye denir.
        fiyat = miktar
    }
    
}
//Nesne Oluşturma
let urun1 = Urunler(id: 1, ad: "TV", fiyat: 12000)

//Değer Atama
//urun1.id = 1
//urun1.ad = "TV"
//urun1.fiyat = 12000

//Değer Okuma
urun1.bilgiAl()
urun1.guncelle(miktar: 20000)
urun1.bilgiAl()

let urun2 = Urunler()

urun2.id = 2
urun2.ad = "Saat"
urun2.fiyat = 5000

urun2.bilgiAl()
urun2.guncelle(miktar: 4000)
urun2.bilgiAl()

//Fonksiyonlar

class Fonksiyonlar{
    //void : geri dönüş değeri olmayan
    func selamla1(){
        print("Merhaba Ahmet")
    }

    //return : geri dönüş değeri olan
    func selamla2() -> String{// Kotlin -> (:), func(fun)
        let  sonuc = "Merhaba Ahmet"
        return sonuc
    }
    
    func topla(sayi1:Int,sayi2:Int){
        print("Toplam : \(sayi1 + sayi2)")
    }
    
    func topla(sayi1:Double,sayi2:Double){ //Overloading
        print("Toplam : \(sayi1 + sayi2)")
    }
    
    func topla(sayi1:Int,sayi2:Int,isim:String){
        print("Toplam : \(sayi1 + sayi2) - İşlem Yapan : \(isim)")
    }


    
}

let f = Fonksiyonlar()
f.selamla1()

let gelenSonuc = f.selamla2()
print("GelenSonuç : \(gelenSonuc)")

f.topla(sayi1: 10, sayi2: 20)
f.topla(sayi1: 80, sayi2: 60, isim: "Ahmet")

//Static Kullanımı - Kotlin Companion Object

class ClassA {
   static var x = 10
    
  static func metod(){
        print("Metod çalıştı")
    }
}

let a = ClassA()

//print(a.x)//Tek nesne ile erişim
//a.metod()

//Sanal nnesne , Virtual object , Nameless
//print(ClassA().x)//1.nesne
//ClassA().metod()//2.nesne

print(ClassA.x)
ClassA.metod()
//Parantez yok ise static var ise direk nesne oluşturmuş oluyoruz.Genelde yukarıdaki örnek ile cok karıstırılıyor

//Enum - Enumeration
enum Boyut {
    case kucuk
    case orta
    case buyuk
}

func ucret(adet:Int,boyut:Boyut){
    switch boyut{
    case .kucuk: print("Üçret : \(adet*456) ₺")
    case .orta: print("Üçret : \(adet*670) ₺")
    case .buyuk: print("Üçret : \(adet*987) ₺")
    }
}
ucret(adet: 200, boyut: .orta)

//Kalıtım - Inheritance - Miras

class Ev {
    var pencereSayisi:Int?
    
    init(pencereSayisi: Int) {
        self.pencereSayisi = pencereSayisi
    }
}
class Saray:Ev {
    var kuleSayisi:Int?
    
    init(kuleSayisi: Int,pencereSayisi:Int) {
        self.kuleSayisi = kuleSayisi
        super.init(pencereSayisi: pencereSayisi)
    }
}
class Villa:Ev {
    var garajVarmi:Bool?
    init(garajVarmi: Bool,pencereSayisi:Int) {
        self.garajVarmi = garajVarmi
        super.init(pencereSayisi: pencereSayisi)
    }
}
//Override
class Hayvan {
    func sesCikar(){
        print("Sesim Yok")
    }
}
class Memeli:Hayvan {
    
}
class Kedi:Memeli {
    override func sesCikar(){
        print("Miyav Miyav")
    }
}
class Kopek:Memeli {
    override func sesCikar() {
        print("Hav Hav")
    }
}

let hayvan = Hayvan()
let memeli = Memeli()
let kedi = Kedi()
let kopek = Kopek()

hayvan.sesCikar()//Kalıtım yok, kendi metoduna erişiyor.
memeli.sesCikar()//Kalıtım var, üst sınıfın metoduna erişiyor.
kedi.sesCikar()//Kalıtım var, kendi metoduna erişiyor.
kopek.sesCikar()//Kalıtım var, kendi metoduna erişiyor.

//Protocol
protocol MyProtocol {
    var degisken:Int {get set}
    
    func metod1()
    func metod2() -> String
}

class MyClass:MyProtocol {
    var degisken: Int = 10
    func metod1() {
        print("Metod 1 çalıştı")
    }
    func metod2() -> String {
        return "Metod 2 çalıştı"
    }
}

//Closure
let ifade = {
    print("Merhaba")
}

ifade()
