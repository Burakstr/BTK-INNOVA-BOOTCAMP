import UIKit

// if yapısı
var yas = 18
var isim = "Mehmet"

print(yas >= 18)

if yas >= 18 {
    print("Reşitsiniz")
}else{
    print("Reşit değilsiniz")
}

if isim == "Ahmet" {
    print("Merhaba Ahmet")
}else{
    print("Tanınmayan Kişi")
}

var ka = "admin"
var s = 123456

if ka == "admin" && s == 123456 { //AND: true && true : true olur diger durumlar hep false olur
    print("Hoşgeldiniz")
}else{
    print("Hatalı Giriş")
}

var numara = 100

if numara == 100 || numara == 200 { // OR : false && false : false diger durumlar hep true
    print("Numara 100 veya 200'dür")
}else{
    print("Numara 1001 veya 200 değildir.")
}

// Switch
var sonuc = 2
switch sonuc {
case 1: print("Sonuç : 1")
case 2: print("Sonuç : 2")
case 3: print("Sonuç : 3")
default:
    print("Böyle bir sonuç yok")
}

// Döngüler - Loops
for x in 1...3 {
    print("Döngü 1 : \(x)")
}

// 10 - 20 , 5 er artsin
for y in stride(from: 10, through: 20, by: 5) {
    print("Döngü 2 : \(y)")
    
}
// 20 - 10 , 5 er azalsın
for y in stride(from: 20, through: 10, by: -5) {
    print("Döngü 3 : \(y)")
}
//1,2,3
var sayac = 1

while sayac < 4 {
    print("Döngü 4 : \(sayac)")
    sayac+=1
}

for x in 1...5 {
    if x == 3 {
        break
    }
    print("Döngü 5 : \(x)")
}

for x in 1...5 {
    if x == 3 {
        continue
    }
    print("Döngü 6 : \(x)")
}
